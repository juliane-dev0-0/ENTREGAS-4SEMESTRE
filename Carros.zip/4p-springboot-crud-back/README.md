# Documentação da API

Esta documentação fornece informações sobre como utilizar a API disponibilizada. A API permite realizar operações CRUD em recursos específicos. 

```bash
https://documenter.getpostman.com/view/7221853/2sA3rwNaQF
