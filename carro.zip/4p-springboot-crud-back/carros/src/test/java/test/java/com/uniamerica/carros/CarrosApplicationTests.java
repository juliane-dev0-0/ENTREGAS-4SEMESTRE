package test.java.com.uniamerica.carros;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrosApplicationTests {

	@Test
	void contextLoads() {
	}
}
